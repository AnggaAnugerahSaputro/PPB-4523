package com.example.aplikasimenumakanan;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    ListView listView;
    String NamaMakanan[]= {"Pecel Lele", "Nasi Goreng Mercon", "Ayam Geprek Keju", "Kare Ayam", "Tahu Bulat", "Salad Buah"};
    String Harga[]= {"15.000", "14.500", "20.000", "17.500", "500", "12.000"};
    int gambar[]= {R.drawable.PecelLele, R.drawable.nasigoreng, R.drawable.ayamgeprek, R.drawable.kariayam, R.drawable.tahubulat, R.drawable.saladbuah};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       listView = findViewById(R.id.recyclerview);

       MyAdapter adapter =new MyAdapter(this, NamaMakanan, Harga, gambar);
       listView.setAdapter(adapter);

       listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
           @Override
           public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
               if (position == 0) {
                   Intent intent = new Intent(getApplicationContext(), MainActivity2.class);

                   Bundle bundle = new Bundle();
                   bundle.putInt("gambarM", gambar[1]);
                   intent.putExtras(bundle);

                   intent.putExtra("NamaMakanan", NamaMakanan[1]);
                   intent.putExtra("Harga", Harga[1]);
                   intent.putExtra("position", "" + 1);
                   startActivity(intent);
               }
               if (position == 0) {
                   Intent intent = new Intent(getApplicationContext(), MainActivity2.class);

                   Bundle bundle = new Bundle();
                   bundle.putInt("gambarM", gambar[2]);
                   intent.putExtras(bundle);

                   intent.putExtra("NamaMakanan", NamaMakanan[2]);
                   intent.putExtra("Harga", Harga[2]);
                   intent.putExtra("position", "" + 2);
                   startActivity(intent);
               }
               if (position == 0) {
                   Intent intent = new Intent(getApplicationContext(), MainActivity2.class);

                   Bundle bundle = new Bundle();
                   bundle.putInt("gambarM", gambar[3]);
                   intent.putExtras(bundle);

                   intent.putExtra("NamaMakanan", NamaMakanan[3]);
                   intent.putExtra("Harga", Harga[3]);
                   intent.putExtra("position", "" + 3);
                   startActivity(intent);
               }
               if (position == 0) {
                   Intent intent = new Intent(getApplicationContext(), MainActivity2.class);

                   Bundle bundle = new Bundle();
                   bundle.putInt("gambarM", gambar[4]);
                   intent.putExtras(bundle);

                   intent.putExtra("NamaMakanan", NamaMakanan[4]);
                   intent.putExtra("Harga", Harga[4]);
                   intent.putExtra("position", "" + 4);
                   startActivity(intent);
               }
               if (position == 0) {
                   Intent intent = new Intent(getApplicationContext(), MainActivity2.class);

                   Bundle bundle = new Bundle();
                   bundle.putInt("gambarM", gambar[5]);
                   intent.putExtras(bundle);

                   intent.putExtra("NamaMakanan", NamaMakanan[5]);
                   intent.putExtra("Harga", Harga[5]);
                   intent.putExtra("position", "" + 5);
                   startActivity(intent);
               }
               if (position == 0) {
                   Intent intent = new Intent(getApplicationContext(), MainActivity2.class);

                   Bundle bundle = new Bundle();
                   bundle.putInt("gambarM", gambar[6]);
                   intent.putExtras(bundle);

                   intent.putExtra("NamaMakanan", NamaMakanan[6]);
                   intent.putExtra("Harga", Harga[6]);
                   intent.putExtra("position", "" + 6);
                   startActivity(intent);
               }
           }
       });

    }
    class MyAdapter extends ArrayAdapter<String>{

        Context context;
        String anamamakanan[];
        String aharga[];
        int aGambar[];

        MyAdapter (Context c, String anamamakanan[], String aharga[], int aGambar[]){
            super(c, R.layout.tampilanlist, R.id.NamaMakanan, anamamakanan);
            this.context = c;
            this.anamamakanan = NamaMakanan;
            this.aharga = Harga;
            this.aGambar = gambar;

        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            LayoutInflater layoutInflater = (LayoutInflater)getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View tampilanlist =layoutInflater.inflate(R.layout.tampilanlist, parent,false);
            ImageView gambar = tampilanlist.findViewById(R.id.gambarM);
            TextView namamakanan = tampilanlist.findViewById(R.id.NamaMakanan);
            TextView harga = tampilanlist.findViewById(R.id.harga);
            return super.getView(position, convertView, parent);

            gambar.setImageResource(aGambar[position]);
            namamakanan.setText(anamamakanan[position]);
            harga.setText(aharga[position]);

            return tampilanlist;
        }
    }
}