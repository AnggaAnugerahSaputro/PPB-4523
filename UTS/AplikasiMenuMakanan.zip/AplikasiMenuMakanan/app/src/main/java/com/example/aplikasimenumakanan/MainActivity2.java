package com.example.aplikasimenumakanan;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
    ImageView imageView;
    TextView makanan, hargamakan;
    int position;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity2);

        ActionBar actionBar = getSupportActionBar();

        if (actionBar != null){
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setDisplayShowHomeEnabled(true);

        }
        imageView = findViewById(R.id.gambarD);
        makanan = findViewById(R.id.namamakananD);
        hargamakan = findViewById(R.id.hargamakanan);

        if (position == 0){
            Intent intent = getIntent();

            Bundle bundle = this.getIntent().getExtras();
            int pict = bundle.getInt("gambarM");
            String bNama = intent.getStringExtra("NamaMakanan");
            String bHarga = intent.getStringExtra("Harga");

            imageView.setImageResource(pict);
            makanan.setText(bNama);
            hargamakan.setText(bHarga);

            actionBar.setTitle(bNama);
        }
        if (position == 1){
            Intent intent = getIntent();

            Bundle bundle = this.getIntent().getExtras();
            int pict = bundle.getInt("gambarM");
            String bNama = intent.getStringExtra("NamaMakanan");
            String bHarga = intent.getStringExtra("Harga");

            imageView.setImageResource(pict);
            makanan.setText(bNama);
            hargamakan.setText(bHarga);

            actionBar.setTitle(bNama);
        }
        if (position == 2){
            Intent intent = getIntent();

            Bundle bundle = this.getIntent().getExtras();
            int pict = bundle.getInt("gambarM");
            String bNama = intent.getStringExtra("NamaMakanan");
            String bHarga = intent.getStringExtra("Harga");

            imageView.setImageResource(pict);
            makanan.setText(bNama);
            hargamakan.setText(bHarga);

            actionBar.setTitle(bNama);
        }
        if (position == 3){
            Intent intent = getIntent();

            Bundle bundle = this.getIntent().getExtras();
            int pict = bundle.getInt("gambarM");
            String bNama = intent.getStringExtra("NamaMakanan");
            String bHarga = intent.getStringExtra("Harga");

            imageView.setImageResource(pict);
            makanan.setText(bNama);
            hargamakan.setText(bHarga);

            actionBar.setTitle(bNama);
        }
        if (position == 4){
            Intent intent = getIntent();

            Bundle bundle = this.getIntent().getExtras();
            int pict = bundle.getInt("gambarM");
            String bNama = intent.getStringExtra("NamaMakanan");
            String bHarga = intent.getStringExtra("Harga");

            imageView.setImageResource(pict);
            makanan.setText(bNama);
            hargamakan.setText(bHarga);

            actionBar.setTitle(bNama);
        }
        if (position == 5){
            Intent intent = getIntent();

            Bundle bundle = this.getIntent().getExtras();
            int pict = bundle.getInt("gambarM");
            String bNama = intent.getStringExtra("NamaMakanan");
            String bHarga = intent.getStringExtra("Harga");

            imageView.setImageResource(pict);
            makanan.setText(bNama);
            hargamakan.setText(bHarga);

            actionBar.setTitle(bNama);
        }
        if (position == 6){
            Intent intent = getIntent();

            Bundle bundle = this.getIntent().getExtras();
            int pict = bundle.getInt("gambarM");
            String bNama = intent.getStringExtra("NamaMakanan");
            String bHarga = intent.getStringExtra("Harga");

            imageView.setImageResource(pict);
            makanan.setText(bNama);
            hargamakan.setText(bHarga);

            actionBar.setTitle(bNama);
        }
    }
}